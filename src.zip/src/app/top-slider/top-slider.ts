import { Component } from '@angular/core';

@Component({
  selector: 'app-top-slider',
  imports: [],
  templateUrl: './top-slider.html',
  styleUrls: ['./top-slider.css']
})
export class TopSlider { }
